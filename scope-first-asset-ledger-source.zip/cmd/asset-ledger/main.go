// Scope-First Asset Ledger is an offline-first CLI for correlating local asset evidence.
package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/ingest"
	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/ledger"
	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/report"
	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/scope"
)

type inputFiles []string

func (items *inputFiles) String() string { return strings.Join(*items, ",") }

func (items *inputFiles) Set(value string) error {
	if strings.TrimSpace(value) == "" {
		return errors.New("input path cannot be empty")
	}
	*items = append(*items, value)
	return nil
}

func main() {
	var inputs inputFiles
	var scopePath, outputPath, outputFormat, logFormat string
	var dryRun bool

	flags := flag.NewFlagSet("asset-ledger", flag.ExitOnError)
	flags.StringVar(&scopePath, "scope", "", "path to a scope JSON file (required)")
	flags.Var(&inputs, "input", "local JSONL or CSV evidence file; repeat the flag for multiple files")
	flags.StringVar(&outputPath, "output", "-", "output file path, or - for stdout")
	flags.StringVar(&outputFormat, "format", "markdown", "report format: markdown, json, or dot")
	flags.StringVar(&logFormat, "log-format", "text", "log format: text or json")
	flags.BoolVar(&dryRun, "dry-run", false, "validate inputs and print a summary without writing a report")
	flags.Usage = usage
	flags.Parse(os.Args[1:])

	if scopePath == "" || len(inputs) == 0 {
		usage()
		os.Exit(2)
	}
	if !validChoice(outputFormat, "markdown", "json", "dot") {
		fatalf("unsupported format %q; use markdown, json, or dot", outputFormat)
	}
	if !validChoice(logFormat, "text", "json") {
		fatalf("unsupported log format %q; use text or json", logFormat)
	}

	policy, err := scope.Load(scopePath)
	if err != nil {
		fatalf("load scope: %v", err)
	}
	logger := newLogger(os.Stderr, logFormat)
	logger("scope loaded", map[string]any{"file": scopePath, "roots": len(policy.RootDomains), "hosts": len(policy.ExactHosts), "cidrs": len(policy.CIDRs)})

	entries, err := ingest.Files(inputs)
	if err != nil {
		fatalf("ingest evidence: %v", err)
	}
	result := ledger.Build(policy, entries)
	logger("evidence normalized", map[string]any{"input_records": len(entries), "entities": len(result.Entities), "in_scope": result.Summary.InScope, "review": result.Summary.Review, "out_of_scope": result.Summary.OutOfScope})

	if dryRun {
		fmt.Fprintf(os.Stdout, "validated %d records from %d file(s): %d entities (%d in-scope, %d review, %d out-of-scope)\n", len(entries), len(inputs), len(result.Entities), result.Summary.InScope, result.Summary.Review, result.Summary.OutOfScope)
		return
	}

	contents, err := report.Render(outputFormat, result)
	if err != nil {
		fatalf("render report: %v", err)
	}
	if err := writeOutput(outputPath, contents); err != nil {
		fatalf("write report: %v", err)
	}
	logger("report written", map[string]any{"format": outputFormat, "output": outputPath})
}

func writeOutput(path string, contents []byte) error {
	if path == "-" {
		_, err := os.Stdout.Write(contents)
		return err
	}
	return os.WriteFile(path, contents, 0o600)
}

func validChoice(value string, choices ...string) bool {
	for _, choice := range choices {
		if value == choice {
			return true
		}
	}
	return false
}

func newLogger(writer io.Writer, format string) func(string, map[string]any) {
	return func(message string, fields map[string]any) {
		if format == "json" {
			payload := map[string]any{"message": message, "fields": fields}
			encoded, _ := json.Marshal(payload)
			fmt.Fprintln(writer, string(encoded))
			return
		}
		fmt.Fprintf(writer, "asset-ledger: %s", message)
		for key, value := range fields {
			fmt.Fprintf(writer, " %s=%v", key, value)
		}
		fmt.Fprintln(writer)
	}
}

func usage() {
	fmt.Fprint(os.Stderr, `Scope-First Asset Ledger

Offline-first correlation of local reconnaissance evidence. This program never
enumerates, probes, authenticates to, or otherwise contacts a target.

Usage:
  asset-ledger --scope scope.json --input observations.jsonl [--input more.csv]
    [--format markdown|json|dot] [--output report.md] [--dry-run]

Examples:
  asset-ledger --scope examples/scope.json --input examples/observations.jsonl
  asset-ledger --scope examples/scope.json --input examples/observations.csv --format json

`)
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "asset-ledger: "+format+"\n", args...)
	os.Exit(1)
}
