module github.com/MohamedAtefMohamed/scope-first-asset-ledger

go 1.22
