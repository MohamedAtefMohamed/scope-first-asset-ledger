# Security Policy

## Scope of this project

Scope-First Asset Ledger is designed to process local evidence only. Security issues in scope include unsafe path handling, uncontrolled resource use from malformed files, report injection, incorrect scope decisions, and any behavior that could cause network activity.

## Reporting a vulnerability

Please do not open a public issue for a suspected vulnerability. Contact the maintainer through the contact method listed on the GitHub profile with a concise reproduction using non-sensitive fixture data. Include the affected version, environment, impact, and a minimal local proof. Do not include real targets, credentials, customer data, or exploit chains.

## Supported versions

The `main` branch is the supported pre-release line until the first tagged release.
