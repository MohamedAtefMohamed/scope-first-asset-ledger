# Scope-First Asset Ledger

**Offline-first evidence correlation for authorized security reviews.**

Scope-First Asset Ledger normalizes **locally supplied** JSONL or CSV observations, applies a declared scope policy, preserves provenance, deduplicates equivalent evidence, and renders a reviewable Markdown, JSON, or Graphviz DOT ledger.

> **Authorization boundary:** this tool does not enumerate domains, probe hosts, crawl URLs, authenticate, contact APIs, or otherwise make network requests. It only processes files an operator provides locally.

## Why it exists

Asset-discovery and HTTP-probing tools already perform active and passive collection. The difficult handoff is often turning mixed outputs into a reliable inventory that explains what is in scope, what needs review, and where every record came from. This tool addresses that handoff without becoming another scanner wrapper.

## Features

- Imports local `.jsonl`, `.ndjson`, and `.csv` evidence files.
- Enforces declared root-domain, exact-host, and CIDR scope policy.
- Labels every entity as `in-scope`, `review`, or `out-of-scope` with a reason.
- Preserves source and local file/line provenance through deduplication.
- Emits stable Markdown, JSON, and Graphviz DOT reports.
- Provides strict input errors, `--dry-run`, structured logging, examples, and tests.

## Quick Start

```sh
go run ./cmd/asset-ledger \
  --scope examples/scope.json \
  --input examples/observations.jsonl \
  --format markdown \
  --output ledger.md
```

The example creates a local `ledger.md` report. It does not contact `example.com`, `partner.test`, or any other host.

## Input Model

The scope file explicitly lists allowed root domains, exact hosts, and CIDRs. Evidence files contain observations that have already been collected by the operator.

```text
scope policy + local JSONL/CSV
              │
              ▼
     parse + normalize + validate
              │
              ▼
    scope decision + provenance ledger
              │
        ┌─────┼─────┐
        ▼     ▼     ▼
     Markdown JSON  DOT
```

See [input formats](docs/input-formats.md) and the [architecture note](docs/architecture.md) for the exact schemas and package roles.

## CLI

```text
asset-ledger --scope scope.json --input observations.jsonl [--input more.csv]
  [--format markdown|json|dot] [--output report.md] [--dry-run]
```

| Flag | Purpose |
|---|---|
| `--scope` | Required path to local scope JSON. |
| `--input` | Required local JSONL/CSV evidence path; may be repeated. |
| `--format` | `markdown` (default), `json`, or `dot`. |
| `--output` | File path or `-` for standard output. |
| `--dry-run` | Validate and summarize without generating a report. |
| `--log-format` | `text` (default) or `json`. |

## Development

```sh
go test ./...
go vet ./...
go run ./cmd/asset-ledger --scope examples/scope.json --input examples/observations.jsonl --dry-run
```

## Limitations

- This is an inventory and evidence-correlation utility, not a vulnerability scanner or risk-scoring engine.
- Scope decisions are only as accurate as the operator’s declared policy and input evidence.
- v0.1 accepts a documented generic JSONL/CSV schema; direct adapters for third-party tool formats are intentionally deferred until they can be tested against stable fixture data.

## Roadmap

- Add explicit, fixture-backed import adapters for well-defined local export schemas.
- Add a review-decision file for human overrides with reason and timestamp.
- Add signed report manifests for evidence-handoff integrity.
- Keep all future capabilities offline-first unless an explicit, authorization-aware network mode is designed and reviewed.

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Contributions must preserve the offline-first safety boundary and include tests for scope, parser, or report behavior.

## License

Licensed under the [MIT License](LICENSE).
