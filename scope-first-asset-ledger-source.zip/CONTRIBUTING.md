# Contributing

Contributions are welcome when they improve the safety, determinism, or reviewability of local evidence correlation.

## Principles

1. Keep v0.1 offline-first. Do not add network discovery, probing, authentication, crawling, or target interaction without a separately reviewed authorization design.
2. Include table-driven tests for new parsing, scope, deduplication, or output behavior.
3. Add a fixture that contains only documentation-reserved domains and IPs, such as `example.com` and `192.0.2.0/24`.
4. Preserve source provenance; deduplication must not silently discard evidence records.
5. Explain changes in a focused pull request with the problem, approach, test evidence and compatibility impact.

## Local Checks

```sh
gofmt -w ./cmd ./internal
go test ./...
go vet ./...
```
