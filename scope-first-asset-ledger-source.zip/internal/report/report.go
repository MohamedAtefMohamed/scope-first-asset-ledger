// Package report renders human-reviewable report formats without making network requests.
package report

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
)

// Render converts a ledger result to a requested stable output format.
func Render(format string, result model.Result) ([]byte, error) {
	switch format {
	case "json":
		return json.MarshalIndent(result, "", "  ")
	case "markdown":
		return markdown(result), nil
	case "dot":
		return dot(result), nil
	default:
		return nil, fmt.Errorf("unsupported format %q", format)
	}
}

func markdown(result model.Result) []byte {
	var buffer bytes.Buffer
	fmt.Fprintln(&buffer, "# Scope-First Asset Ledger")
	fmt.Fprintln(&buffer, "")
	fmt.Fprintln(&buffer, "> Generated from operator-supplied local evidence. This report is an inventory aid, not a vulnerability assessment.")
	fmt.Fprintln(&buffer, "")
	fmt.Fprintf(&buffer, "**Summary:** %d in-scope · %d review · %d out-of-scope entities\n\n", result.Summary.InScope, result.Summary.Review, result.Summary.OutOfScope)
	fmt.Fprintln(&buffer, "| Entity | URLs | IPs | Ports | Scope decision | Why | Sources |")
	fmt.Fprintln(&buffer, "|---|---|---|---:|---|---|---|")
	for _, entity := range result.Entities {
		sources := make([]string, 0, len(entity.Evidence))
		for _, evidence := range entity.Evidence {
			sources = append(sources, evidence.Source+" ("+evidence.Reference+")")
		}
		fmt.Fprintf(&buffer, "| %s | %s | %s | %s | %s | %s | %s |\n", clean(entity.Key), clean(strings.Join(entity.URLs, "<br>")), clean(strings.Join(entity.IPs, "<br>")), clean(joinPorts(entity.Ports)), entity.Status, clean(entity.Reason), clean(strings.Join(sources, "<br>")))
	}
	return buffer.Bytes()
}

func dot(result model.Result) []byte {
	var buffer bytes.Buffer
	fmt.Fprintln(&buffer, "digraph AssetLedger {")
	fmt.Fprintln(&buffer, "  rankdir=LR;")
	fmt.Fprintln(&buffer, "  node [fontname=\"Arial\", style=filled, fillcolor=\"#f8fafc\", color=\"#334155\"];")
	for _, entity := range result.Entities {
		hostID := dotID(entity.Key)
		fmt.Fprintf(&buffer, "  %s [label=\"%s\\n%s\", fillcolor=\"%s\"];\n", hostID, dotText(entity.Key), entity.Status, statusColor(entity.Status))
		for _, ip := range entity.IPs {
			ipID := dotID("ip:" + ip)
			fmt.Fprintf(&buffer, "  %s [label=\"%s\", shape=box];\n  %s -> %s [label=\"resolves\"];\n", ipID, dotText(ip), hostID, ipID)
		}
		for _, url := range entity.URLs {
			urlID := dotID("url:" + url)
			fmt.Fprintf(&buffer, "  %s [label=\"%s\", shape=note];\n  %s -> %s [label=\"observed\"];\n", urlID, dotText(url), hostID, urlID)
		}
	}
	fmt.Fprintln(&buffer, "}")
	return buffer.Bytes()
}

func joinPorts(ports []int) string {
	values := make([]string, 0, len(ports))
	for _, port := range ports {
		values = append(values, fmt.Sprintf("%d", port))
	}
	return strings.Join(values, ", ")
}

func clean(value string) string {
	return strings.ReplaceAll(strings.ReplaceAll(value, "|", "\\|"), "\n", " ")
}
func dotID(value string) string { return "n" + fmt.Sprintf("%x", []byte(value)) }
func dotText(value string) string {
	return strings.ReplaceAll(strings.ReplaceAll(value, "\\", "\\\\"), "\"", "\\\"")
}

func statusColor(status model.ScopeStatus) string {
	switch status {
	case model.InScope:
		return "#dcfce7"
	case model.Review:
		return "#fef3c7"
	default:
		return "#fee2e2"
	}
}
