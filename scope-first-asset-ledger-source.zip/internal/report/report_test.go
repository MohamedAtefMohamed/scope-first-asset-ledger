package report

import (
	"strings"
	"testing"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
)

func TestRenderMarkdownContainsScopeDecision(t *testing.T) {
	result := model.Result{Entities: []model.Entity{{Key: "host:api.example.com", Status: model.InScope, Reason: "host matches declared root domain"}}, Summary: model.Summary{InScope: 1}}
	output, err := Render("markdown", result)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(output), "in-scope") {
		t.Fatal("markdown report omits scope decision")
	}
}
