package ledger

import (
	"testing"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/scope"
)

func TestBuildDeduplicatesHostAndPreservesEvidence(t *testing.T) {
	policy := scope.Policy{RootDomains: []string{"example.com"}}
	result := Build(policy, []model.Observation{
		{Host: "api.example.com", URL: "https://api.example.com", Source: "fixture", Reference: "one"},
		{Host: "api.example.com", IP: "192.0.2.10", Port: 443, Source: "fixture", Reference: "two"},
	})
	if len(result.Entities) != 1 {
		t.Fatalf("got %d entities, want 1", len(result.Entities))
	}
	if len(result.Entities[0].Evidence) != 2 {
		t.Fatalf("got %d evidence rows, want 2", len(result.Entities[0].Evidence))
	}
	if result.Summary.InScope != 1 {
		t.Fatalf("got %d in-scope entities, want 1", result.Summary.InScope)
	}
}
