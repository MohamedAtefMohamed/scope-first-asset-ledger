// Package ledger correlates local observations into provenance-preserving entities.
package ledger

import (
	"fmt"
	"sort"
	"strings"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/scope"
)

// Build applies scope policy, aggregates equivalent evidence, and creates a stable result.
func Build(policy scope.Policy, observations []model.Observation) model.Result {
	entities := make(map[string]*model.Entity)
	for _, observation := range observations {
		status, reason := policy.Evaluate(observation)
		key := entityKey(observation)
		entity, exists := entities[key]
		if !exists {
			entity = &model.Entity{Key: key, Host: observation.Host, Status: status, Reason: reason}
			entities[key] = entity
		} else if severity(status) > severity(entity.Status) {
			entity.Status, entity.Reason = status, reason
		}
		entity.URLs = appendUnique(entity.URLs, observation.URL)
		entity.IPs = appendUnique(entity.IPs, observation.IP)
		entity.Ports = appendUniqueInt(entity.Ports, observation.Port)
		for _, technology := range observation.Technologies {
			entity.Technologies = appendUnique(entity.Technologies, technology)
		}
		entity.Evidence = append(entity.Evidence, observation)
	}

	result := model.Result{Entities: make([]model.Entity, 0, len(entities))}
	for _, entity := range entities {
		sort.Strings(entity.URLs)
		sort.Strings(entity.IPs)
		sort.Ints(entity.Ports)
		sort.Strings(entity.Technologies)
		sort.Slice(entity.Evidence, func(left, right int) bool { return entity.Evidence[left].Reference < entity.Evidence[right].Reference })
		result.Entities = append(result.Entities, *entity)
		switch entity.Status {
		case model.InScope:
			result.Summary.InScope++
		case model.Review:
			result.Summary.Review++
		case model.OutOfScope:
			result.Summary.OutOfScope++
		}
	}
	sort.Slice(result.Entities, func(left, right int) bool { return result.Entities[left].Key < result.Entities[right].Key })
	return result
}

func entityKey(observation model.Observation) string {
	if observation.Host != "" {
		return "host:" + observation.Host
	}
	if observation.IP != "" {
		return "ip:" + observation.IP
	}
	if observation.URL != "" {
		return "url:" + observation.URL
	}
	return fmt.Sprintf("evidence:%s", observation.Reference)
}

func severity(status model.ScopeStatus) int {
	switch status {
	case model.OutOfScope:
		return 3
	case model.Review:
		return 2
	default:
		return 1
	}
}

func appendUnique(values []string, candidate string) []string {
	candidate = strings.TrimSpace(candidate)
	if candidate == "" {
		return values
	}
	for _, value := range values {
		if value == candidate {
			return values
		}
	}
	return append(values, candidate)
}

func appendUniqueInt(values []int, candidate int) []int {
	if candidate <= 0 {
		return values
	}
	for _, value := range values {
		if value == candidate {
			return values
		}
	}
	return append(values, candidate)
}
