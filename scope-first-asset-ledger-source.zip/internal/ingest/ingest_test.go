package ingest

import (
	"path/filepath"
	"testing"
)

func TestFileJSONL(t *testing.T) {
	items, err := File(filepath.Join("..", "..", "fixtures", "observations.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 3 {
		t.Fatalf("got %d observations, want 3", len(items))
	}
	if items[0].Reference == "" || items[0].Source == "" {
		t.Fatal("expected normalized provenance")
	}
}

func TestFileCSV(t *testing.T) {
	items, err := File(filepath.Join("..", "..", "fixtures", "observations.csv"))
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 2 {
		t.Fatalf("got %d observations, want 2", len(items))
	}
	if items[0].Port != 443 {
		t.Fatalf("got port %d, want 443", items[0].Port)
	}
}
