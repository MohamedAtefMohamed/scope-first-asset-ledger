// Package ingest imports local JSONL and CSV observations without network access.
package ingest

import (
	"bufio"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
)

// Files imports multiple local evidence files.
func Files(paths []string) ([]model.Observation, error) {
	var observations []model.Observation
	for _, path := range paths {
		items, err := File(path)
		if err != nil {
			return nil, err
		}
		observations = append(observations, items...)
	}
	return observations, nil
}

// File imports JSONL or CSV based on file extension.
func File(path string) ([]model.Observation, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	switch strings.ToLower(filepath.Ext(path)) {
	case ".jsonl", ".ndjson":
		return jsonLines(file, path)
	case ".csv":
		return commaSeparated(file, path)
	default:
		return nil, fmt.Errorf("%s: unsupported extension; use .jsonl, .ndjson, or .csv", path)
	}
}

func jsonLines(reader io.Reader, path string) ([]model.Observation, error) {
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 64*1024), 1024*1024)
	var results []model.Observation
	line := 0
	for scanner.Scan() {
		line++
		text := strings.TrimSpace(scanner.Text())
		if text == "" {
			continue
		}
		var observation model.Observation
		if err := json.Unmarshal([]byte(text), &observation); err != nil {
			return nil, fmt.Errorf("%s:%d: invalid JSONL: %w", path, line, err)
		}
		results = append(results, normalize(observation, fmt.Sprintf("%s:%d", path, line)))
	}
	return results, scanner.Err()
}

func commaSeparated(reader io.Reader, path string) ([]model.Observation, error) {
	rows, err := csv.NewReader(reader).ReadAll()
	if err != nil {
		return nil, err
	}
	if len(rows) < 2 {
		return nil, fmt.Errorf("%s: CSV must contain a header and at least one record", path)
	}
	index := make(map[string]int, len(rows[0]))
	for position, column := range rows[0] {
		index[strings.ToLower(strings.TrimSpace(column))] = position
	}
	for _, required := range []string{"host", "url", "ip", "port", "source"} {
		if _, ok := index[required]; !ok {
			return nil, fmt.Errorf("%s: CSV is missing required %q column", path, required)
		}
	}
	var results []model.Observation
	for rowNumber, row := range rows[1:] {
		if len(row) != len(rows[0]) {
			return nil, fmt.Errorf("%s:%d: expected %d columns, got %d", path, rowNumber+2, len(rows[0]), len(row))
		}
		port, err := strconv.Atoi(strings.TrimSpace(row[index["port"]]))
		if err != nil && strings.TrimSpace(row[index["port"]]) != "" {
			return nil, fmt.Errorf("%s:%d: port must be numeric", path, rowNumber+2)
		}
		observation := model.Observation{Host: row[index["host"]], URL: row[index["url"]], IP: row[index["ip"]], Port: port, Source: row[index["source"]]}
		if technology, ok := index["technologies"]; ok && strings.TrimSpace(row[technology]) != "" {
			observation.Technologies = strings.Split(row[technology], ";")
		}
		results = append(results, normalize(observation, fmt.Sprintf("%s:%d", path, rowNumber+2)))
	}
	return results, nil
}

func normalize(observation model.Observation, fallbackReference string) model.Observation {
	observation.Host = strings.TrimSuffix(strings.ToLower(strings.TrimSpace(observation.Host)), ".")
	observation.URL = strings.TrimSpace(observation.URL)
	observation.IP = strings.TrimSpace(observation.IP)
	observation.Source = strings.TrimSpace(observation.Source)
	if observation.Source == "" {
		observation.Source = "unspecified-local-input"
	}
	if strings.TrimSpace(observation.Reference) == "" {
		observation.Reference = fallbackReference
	}
	seen := make(map[string]struct{}, len(observation.Technologies))
	var technologies []string
	for _, technology := range observation.Technologies {
		technology = strings.TrimSpace(technology)
		if technology != "" {
			if _, exists := seen[technology]; !exists {
				seen[technology] = struct{}{}
				technologies = append(technologies, technology)
			}
		}
	}
	observation.Technologies = technologies
	return observation
}
