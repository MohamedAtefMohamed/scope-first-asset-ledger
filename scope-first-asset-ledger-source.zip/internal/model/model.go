// Package model contains the normalized, serializable evidence types.
package model

// Observation is one locally supplied evidence record before correlation.
type Observation struct {
	Host         string   `json:"host"`
	URL          string   `json:"url"`
	IP           string   `json:"ip"`
	Port         int      `json:"port"`
	Technologies []string `json:"technologies,omitempty"`
	Source       string   `json:"source"`
	Reference    string   `json:"reference"`
}

// ScopeStatus is the human-review outcome of the declared scope policy.
type ScopeStatus string

const (
	InScope    ScopeStatus = "in-scope"
	Review     ScopeStatus = "review"
	OutOfScope ScopeStatus = "out-of-scope"
)

// Entity merges equivalent observations without discarding source provenance.
type Entity struct {
	Key          string        `json:"key"`
	Host         string        `json:"host,omitempty"`
	URLs         []string      `json:"urls,omitempty"`
	IPs          []string      `json:"ips,omitempty"`
	Ports        []int         `json:"ports,omitempty"`
	Technologies []string      `json:"technologies,omitempty"`
	Status       ScopeStatus   `json:"status"`
	Reason       string        `json:"reason"`
	Evidence     []Observation `json:"evidence"`
}

// Summary is a stable count of the review outcomes.
type Summary struct {
	InScope    int `json:"in_scope"`
	Review     int `json:"review"`
	OutOfScope int `json:"out_of_scope"`
}

// Result is the complete correlation output.
type Result struct {
	Entities []Entity `json:"entities"`
	Summary  Summary  `json:"summary"`
}
