package scope

import (
	"net"
	"testing"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
)

func TestEvaluate(t *testing.T) {
	_, network, err := net.ParseCIDR("192.0.2.0/24")
	if err != nil {
		t.Fatal(err)
	}
	policy := Policy{RootDomains: []string{"example.com"}, ExactHosts: []string{"portal.partner.test"}, CIDRs: []string{"192.0.2.0/24"}, nets: []*net.IPNet{network}}

	cases := []struct {
		name        string
		observation model.Observation
		want        model.ScopeStatus
	}{
		{"root", model.Observation{Host: "api.example.com"}, model.InScope},
		{"exact", model.Observation{Host: "portal.partner.test"}, model.InScope},
		{"cidr", model.Observation{IP: "192.0.2.42"}, model.InScope},
		{"out", model.Observation{Host: "api.example.net", IP: "198.51.100.8"}, model.OutOfScope},
		{"review", model.Observation{}, model.Review},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			got, _ := policy.Evaluate(test.observation)
			if got != test.want {
				t.Fatalf("Evaluate() = %s, want %s", got, test.want)
			}
		})
	}
}
