// Package scope loads an explicit local scope policy and evaluates evidence against it.
package scope

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sort"
	"strings"

	"github.com/MohamedAtefMohamed/scope-first-asset-ledger/internal/model"
)

// Policy declares the only roots, hosts and IP ranges considered in scope.
type Policy struct {
	RootDomains []string `json:"root_domains"`
	ExactHosts  []string `json:"exact_hosts"`
	CIDRs       []string `json:"cidrs"`
	nets        []*net.IPNet
}

// Load reads and validates a JSON policy. Empty policies are rejected.
func Load(path string) (Policy, error) {
	contents, err := os.ReadFile(path)
	if err != nil {
		return Policy{}, err
	}
	var policy Policy
	if err := json.Unmarshal(contents, &policy); err != nil {
		return Policy{}, fmt.Errorf("parse JSON: %w", err)
	}
	policy.RootDomains = normalizeHosts(policy.RootDomains)
	policy.ExactHosts = normalizeHosts(policy.ExactHosts)
	if len(policy.RootDomains)+len(policy.ExactHosts)+len(policy.CIDRs) == 0 {
		return Policy{}, fmt.Errorf("scope must define at least one root domain, exact host, or CIDR")
	}
	for _, rawCIDR := range policy.CIDRs {
		_, network, err := net.ParseCIDR(strings.TrimSpace(rawCIDR))
		if err != nil {
			return Policy{}, fmt.Errorf("invalid CIDR %q: %w", rawCIDR, err)
		}
		policy.nets = append(policy.nets, network)
	}
	return policy, nil
}

// Evaluate returns a conservative scope decision and a reviewable reason.
func (policy Policy) Evaluate(observation model.Observation) (model.ScopeStatus, string) {
	host := normalizeHost(observation.Host)
	if host != "" {
		for _, exact := range policy.ExactHosts {
			if host == exact {
				return model.InScope, "exact host matches declared scope"
			}
		}
		for _, root := range policy.RootDomains {
			if host == root || strings.HasSuffix(host, "."+root) {
				return model.InScope, "host matches declared root domain"
			}
		}
	}
	if parsedIP := net.ParseIP(strings.TrimSpace(observation.IP)); parsedIP != nil {
		for _, network := range policy.nets {
			if network.Contains(parsedIP) {
				return model.InScope, "IP address matches declared CIDR"
			}
		}
	}
	if host == "" && strings.TrimSpace(observation.IP) == "" {
		return model.Review, "no host or IP evidence available for scope decision"
	}
	return model.OutOfScope, "host and IP do not match declared scope"
}

func normalizeHost(host string) string {
	return strings.TrimSuffix(strings.ToLower(strings.TrimSpace(host)), ".")
}

func normalizeHosts(hosts []string) []string {
	set := make(map[string]struct{}, len(hosts))
	for _, host := range hosts {
		if normalized := normalizeHost(host); normalized != "" {
			set[normalized] = struct{}{}
		}
	}
	output := make([]string, 0, len(set))
	for host := range set {
		output = append(output, host)
	}
	sort.Strings(output)
	return output
}
