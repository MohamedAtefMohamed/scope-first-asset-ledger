# Input Formats

Scope-First Asset Ledger only reads local evidence files. It does not start a scan, open a socket, request a URL, authenticate, or look up a domain.

## Scope JSON

```json
{
  "root_domains": ["example.com"],
  "exact_hosts": ["partner.example.net"],
  "cidrs": ["192.0.2.0/24"]
}
```

At least one list must contain a value. A record is **in-scope** when its normalized host matches an exact host or root domain, or when its IP is contained in a declared CIDR. Records with no host or IP become **review**; nonmatching evidence becomes **out-of-scope**.

## JSONL / NDJSON

One JSON object per line. `host`, `url`, `ip`, `port`, and `source` are supported; `technologies` is optional.

```json
{"host":"api.example.com","url":"https://api.example.com/v1","ip":"192.0.2.10","port":443,"technologies":["nginx"],"source":"operator-export","reference":"input.jsonl:1"}
```

When `reference` is absent, the ledger records the local path and line number. When `source` is absent, it records `unspecified-local-input`.

## CSV

CSV must include `host`, `url`, `ip`, `port`, and `source` headers. An optional `technologies` column accepts a semicolon-separated list.

```csv
host,url,ip,port,source,technologies
api.example.com,https://api.example.com,192.0.2.10,443,operator-export,nginx;Go
```
