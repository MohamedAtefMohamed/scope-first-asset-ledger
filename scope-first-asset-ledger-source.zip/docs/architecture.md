# Architecture

The CLI is intentionally split into small packages:

| Package | Responsibility |
|---|---|
| `internal/ingest` | Parse local JSONL/CSV files and retain local provenance. |
| `internal/scope` | Validate the declared policy and produce a conservative scope decision. |
| `internal/ledger` | Deduplicate evidence into stable entities without discarding source records. |
| `internal/report` | Render deterministic JSON, Markdown, or DOT output. |
| `cmd/asset-ledger` | Provide CLI flags, error handling and structured logging. |

The initial release has no outbound-network capability. This keeps the authorization boundary straightforward: an operator can review scope decisions about data they have supplied without accidentally initiating discovery or probing.
